from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def home(request):
    return render(request, 'home.html', {'name':'Priya'})

def add(request):
    first = int(request.POST['first'])
    second = int(request.POST['second'])
    val = first+second
    return render(request, 'add.html',{'sum':val})