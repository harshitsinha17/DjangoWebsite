from django.shortcuts import render,redirect
from django.contrib.auth.models import User

# Create your views here.
def register(request):
    if request.method == 'GET' :
        return render(request, 'register.html')
    else:

        first = request.POST['first']
        last = request.POST['last']
        email = request.POST['email']
        usrs = User.objects.create_user(username = first,last_name=last,email=email)
        print("User was created")
        usrs.save()
        return redirect('/')
            